<?php
//get data from form  

$name = $_POST['name'];
$mobile= $_POST['mobile'];
$email= $_POST['email'];
$message= $_POST['message'];
$to = "vcsa.guwahati@gmail.com";
$subject = "Contact Us";
$txt =" Name: ". $name . "\r\n Mobile: " . $mobile . "\r\n Email: " . $email . "\r\n Message: " . $message;
$headers = "From: SIASA@sankardevias.academy" . "\r\n" .
"CC: ";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thank-you-page-contact-us.html");
?>