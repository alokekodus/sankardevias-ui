<?php
//get data from form  

$name = $_POST['name'];
$mobile= $_POST['mobile'];
$email= $_POST['email'];
$message= $_POST['message'];
$to = "vcsa.guwahati@gmail.com";
$subject = "Free Demo Classes Registration";
$txt ="Name: ". $name . "\r\nMobile: " . $mobile . "\r\nEmail: " . $email . "\r\n;
$headers = "From: SIASA@sankardevias.academy" . "\r\n" .
"CC: ";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:thank-you-page-free-demo-classes.html");
?>